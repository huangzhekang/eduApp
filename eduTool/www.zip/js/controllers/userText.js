define(['app'],function (app) {
    app.controller('userTextCtrl', ['$scope', '$stateParams', function($scope, $stateParams) {

    }]);
});
    
