define(['app'],function (app) {
    app.controller('myactCtrl', ['$scope','$ionicPopup', function($scope, $ionicPopup) {

    }]);
   
});