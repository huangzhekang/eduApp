define(['app'],function (app) {
    app.controller('mypostCtrl', ['$scope','$ionicPopup', function($scope, $ionicPopup) {

    }]);
   
});