define(['app'],function (app) {
    app.controller('friendDetailCtrl', ['$scope','$ionicPopup', function($scope, $ionicPopup) {
        // Triggered on a button click, or some other target

    }]);
   
});