define(['app'],function (app) {
    app.controller('indexCtrl', ['$scope', function($scope) {
    }]);
});
    
