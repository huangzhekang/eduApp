define(['app'],function (app) {
    app.controller('addActCtrl', ['$scope','$ionicPopup', function($scope, $ionicPopup) {

    }]);
   
});